from django.contrib import admin
from blog.models import sagar
# Register your models here.
class Post1(admin.ModelAdmin):
    list_display="id","title","describtion"

admin.site.register(sagar,Post1)     