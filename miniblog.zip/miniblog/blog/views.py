from django.shortcuts import render,HttpResponseRedirect
from django.contrib.auth import login, logout,authenticate
from .forms import user_creation_form,authenticate_form,sagar_form
from django.contrib import messages
from .models import sagar
from django.contrib.auth.models import Group





#Home
def home(request):
    pos=sagar.objects.all()
    return render (request,'blog/home.html',{'post':pos})

#About
def about(request):
    return render(request,'blog/about.html')

#contact
def contact(request):
    return render(request,'blog/contact.html') 

#Dashboard
def dashboard(request):
    if request.user.is_authenticated:
        sag=sagar.objects.all()
        user=request.user
        full_name=user.get_full_name()
        gps=user.groups.all()
        return render(request,'blog/dashboard.html',{'sag':sag,'full_name':full_name,'groups':gps})   
    else:
        return HttpResponseRedirect('/login/')

#logout
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/login/')    

#signup
def user_signup(request):
    if request.method =="POST":
        fm= user_creation_form(request.POST)
        if fm.is_valid():
            save=fm.save()

            group=Group.objects.get(name="Author")
            save.groups.add(group)

            messages.success(request,"Congratulation !! You Have Become An Author !!!!")
    else:        
        fm= user_creation_form()
    return render(request,'blog/signup.html',{'form':fm})   

#login
def user_login(request):
    if not request.user.is_authenticated:
        if request.method=="POST":
            fm=authenticate_form(request=request ,data=request.POST)
            if fm.is_valid():
                    uname = fm.cleaned_data["username"]
                    upass = fm.cleaned_data["password"]
                    user=authenticate(username=uname , password=upass)
                    login(request, user)
                    messages.success(request,'Logged In Successfulley !!!!')
                    return HttpResponseRedirect('/dashboard/')

        else:
            fm=authenticate_form()
        return render(request,'blog/login.html',{'form':fm})   
    else:
        return HttpResponseRedirect('/dashboard/')    



# Add new post
def add_post(request):
    if request.user.is_authenticated:
        if request.method=="POST":
            fm=sagar_form(request.POST)
            if fm.is_valid():
                title=fm.cleaned_data['title']
                describtion=fm.cleaned_data['describtion']
                fm.save()
                fm=sagar_form()
        else: 
            fm=sagar_form()           
        return render(request,"blog/addpost.html",{"form":fm})
    else:
        return HttpResponseRedirect("/login/")    



# Update  post
def update_post(request,id):
    if request.user.is_authenticated:
        if request.method=="POST":
            pi=sagar.objects.get(pk=id)
            fm=sagar_form(request.POST,instance=pi)
            if fm.is_valid():
                fm.save()
        else:
            pi=sagar.objects.get(pk=id)
            fm=sagar_form(instance=pi)        
        return render(request,"blog/updatepost.html",{"form":fm})
    else:
         return HttpResponseRedirect("/login/") 




# delete  post
def delete_post(request,id ):
    if request.user.is_authenticated:
        if request.method=="POST":
            pi=sagar.objects.get(pk=id)
            pi.delete()
        return HttpResponseRedirect("/dashboard/") 
    else:
        return HttpResponseRedirect("/login/") 

